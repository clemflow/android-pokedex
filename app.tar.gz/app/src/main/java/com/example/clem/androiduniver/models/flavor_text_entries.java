package com.example.clem.androiduniver.models;

/**
 * Created by clem on 17/04/17.
 */

public class flavor_text_entries {
    private String flavor_text;
    private language language;

    public String getFlavor_text() {
        return flavor_text;
    }

    public void setFlavor_text(String flavor_text) {
        this.flavor_text = flavor_text;
    }

    public com.example.clem.androiduniver.models.language getLanguage() {
        return language;
    }

    public void setLanguage(com.example.clem.androiduniver.models.language language) {
        this.language = language;
    }
}
