package com.example.clem.androiduniver.models;

/**
 * Created by clem on 14/04/17.
 */

public class names {
    private String name;
    private language language;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public com.example.clem.androiduniver.models.language getLanguage() {
        return language;
    }

    public void setLanguage(com.example.clem.androiduniver.models.language language) {
        this.language = language;
    }
}
