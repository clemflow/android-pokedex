package com.example.clem.androiduniver.models;

/**
 * Created by clem on 14/04/17.
 */

public class language {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
