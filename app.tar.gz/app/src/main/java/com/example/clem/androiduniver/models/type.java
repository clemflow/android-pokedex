package com.example.clem.androiduniver.models;

import java.util.ArrayList;

/**
 * Created by clem on 14/04/17.
 */

public class type {

    private pokemon pokemon;

    public pokemon getPokemon() {
        return pokemon;
    }

    public void setPokemon(pokemon pokemon) {
        this.pokemon = pokemon;
    }

}
